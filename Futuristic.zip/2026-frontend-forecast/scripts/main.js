import { PREDICTIONS_DATA } from './predictions-data.js';

class Frontend2026App {
    constructor() {
        this.currentSection = 'core';
        this.init();
    }

    init() {
        this.setupNavigation();
        this.renderAllSections();
        this.setupTerminal();
        this.setupAnimations();
        this.setupEventListeners();
    }

    setupNavigation() {
        const navButtons = document.querySelectorAll('.nav-btn');
        
        navButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const section = e.target.dataset.section;
                
                // Update active button
                navButtons.forEach(btn => btn.classList.remove('active'));
                e.target.classList.add('active');
                
                // Show selected section
                this.showSection(section);
            });
        });
    }

    showSection(sectionId) {
        // Hide all sections
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });

        // Show selected section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            this.currentSection = sectionId;
            
            // Add visual feedback
            HackerEffects.createPulseEffect(targetSection);
        }
    }

    renderAllSections() {
        this.renderCards('core', PREDICTIONS_DATA.coreLanguages);
        this.renderCards('styling', PREDICTIONS_DATA.stylingLanguages);
        this.renderCards('frameworks', PREDICTIONS_DATA.frameworkLanguages);
        this.renderCards('ai', PREDICTIONS_DATA.aiLanguages);
        this.renderCards('emerging', PREDICTIONS_DATA.emergingTech);
        this.renderComparisonTable();
    }

    renderCards(sectionId, cardsData) {
        const container = document.getElementById(`${sectionId}-cards`);
        if (!container) return;

        container.innerHTML = cardsData.map(card => `
            <div class="card" data-tech="${card.title.toLowerCase()}">
                <div class="card-header">
                    <h3 class="card-title">${card.title}</h3>
                    <span class="card-badge">${card.badge}</span>
                </div>
                <p class="card-subtitle">${card.subtitle}</p>
                <p class="card-description">${card.description}</p>
                
                ${card.features ? `
                    <ul class="card-features">
                        ${card.features.map(feature => `
                            <li><i class="fas fa-check-circle"></i> ${feature}</li>
                        `).join('')}
                    </ul>
                ` : ''}
                
                ${card.code ? `
                    <pre class="card-code">${card.code}</pre>
                ` : ''}
            </div>
        `).join('');

        // Add hover effects to new cards
        this.addCardEffects(container);
    }

    renderComparisonTable() {
        const container = document.getElementById('comparison-table');
        if (!container) return;

        const { comparison } = PREDICTIONS_DATA;
        
        container.innerHTML = `
            <div class="table-header">
                <h3><i class="fas fa-calendar-alt"></i> 2024 (Current)</h3>
                <h3><i class="fas fa-calendar-check"></i> 2026 (Projected)</h3>
            </div>
            <div class="table-body">
                <div class="table-column">
                    ${comparison["2024"].map(item => `
                        <div class="table-item">
                            <h4 class="table-item-title">
                                <i class="fas ${item.icon}"></i> ${item.title}
                            </h4>
                            <p class="table-item-description">${item.description}</p>
                        </div>
                    `).join('')}
                </div>
                <div class="table-column">
                    ${comparison["2026"].map(item => `
                        <div class="table-item">
                            <h4 class="table-item-title">
                                <i class="fas ${item.icon}"></i> ${item.title}
                            </h4>
                            <p class="table-item-description">${item.description}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    addCardEffects(container) {
        const cards = container.querySelectorAll('.card');
        
        cards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.style.transform = 'translateY(-10px)';
                card.style.borderColor = 'var(--primary-red)';
                card.style.boxShadow = '0 10px 30px rgba(255, 0, 60, 0.3)';
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = '';
                card.style.borderColor = '';
                card.style.boxShadow = '';
            });

            // Click to simulate data stream
            card.addEventListener('click', () => {
                const techName = card.querySelector('.card-title').textContent;
                this.simulateTechAnalysis(techName);
            });
        });
    }

    setupTerminal() {
        const terminalInput = document.getElementById('terminal-input');
        const terminalOutput = document.getElementById('terminal-output');

        if (!terminalInput || !terminalOutput) return;

        terminalInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const command = terminalInput.value.trim().toLowerCase();
                terminalInput.value = '';
                
                this.processTerminalCommand(command, terminalOutput);
            }
        });

        // Add initial help message
        setTimeout(() => {
            this.addTerminalMessage(terminalOutput, "Type 'help' for available commands");
        }, 5000);
    }

    processTerminalCommand(command, outputElement) {
        this.addTerminalMessage(outputElement, `> ${command}`);
        
        switch(command) {
            case 'help':
                this.addTerminalMessage(outputElement, "Available commands:");
                this.addTerminalMessage(outputElement, "  • help - Show this message");
                this.addTerminalMessage(outputElement, "  • clear - Clear terminal");
                this.addTerminalMessage(outputElement, "  • stats - Show prediction statistics");
                this.addTerminalMessage(outputElement, "  • tech [name] - Analyze specific tech");
                this.addTerminalMessage(outputElement, "  • predict - Show 2026 predictions");
                this.addTerminalMessage(outputElement, "  • timeline - Show adoption timeline");
                break;
                
            case 'clear':
                outputElement.innerHTML = '';
                break;
                
            case 'stats':
                this.addTerminalMessage(outputElement, "Prediction Statistics:");
                this.addTerminalMessage(outputElement, "  • Confidence Level: 87%");
                this.addTerminalMessage(outputElement, "  • Adoption Rate: 42% projected");
                this.addTerminalMessage(outputElement, "  • Market Demand: 94%");
                this.addTerminalMessage(outputElement, "  • Risk Factor: Medium");
                break;
                
            case 'predict':
                this.addTerminalMessage(outputElement, "Top 2026 Predictions:");
                this.addTerminalMessage(outputElement, "  1. TypeScript becomes mandatory");
                this.addTerminalMessage(outputElement, "  2. WASM for compute-heavy tasks");
                this.addTerminalMessage(outputElement, "  3. Edge computing default");
                this.addTerminalMessage(outputElement, "  4. AI-assisted development standard");
                this.addTerminalMessage(outputElement, "  5. Zero-runtime CSS dominant");
                break;
                
            case 'timeline':
                this.addTerminalMessage(outputElement, "Adoption Timeline:");
                this.addTerminalMessage(outputElement, "  Q1 2025: WebGPU stable");
                this.addTerminalMessage(outputElement, "  Q3 2025: React Forget stable");
                this.addTerminalMessage(outputElement, "  Q1 2026: Edge functions mainstream");
                this.addTerminalMessage(outputElement, "  Q3 2026: AIQL specification");
                break;
                
            default:
                if (command.startsWith('tech ')) {
                    const tech = command.substring(5);
                    this.analyzeTechnology(tech, outputElement);
                } else {
                    this.addTerminalMessage(outputElement, `Unknown command: ${command}`);
                    this.addTerminalMessage(outputElement, "Type 'help' for available commands");
                }
        }
    }

    addTerminalMessage(outputElement, message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'terminal-line';
        messageDiv.innerHTML = `<span class="prompt">>></span> ${message}`;
        outputElement.appendChild(messageDiv);
        
        // Scroll to bottom
        outputElement.scrollTop = outputElement.scrollHeight;
    }

    analyzeTechnology(techName, outputElement) {
        const allTech = [
            ...PREDICTIONS_DATA.coreLanguages,
            ...PREDICTIONS_DATA.stylingLanguages,
            ...PREDICTIONS_DATA.frameworkLanguages,
            ...PREDICTIONS_DATA.aiLanguages,
            ...PREDICTIONS_DATA.emergingTech
        ];
        
        const foundTech = allTech.find(t => 
            t.title.toLowerCase().includes(techName.toLowerCase()) ||
            t.subtitle.toLowerCase().includes(techName.toLowerCase())
        );
        
        if (foundTech) {
            this.addTerminalMessage(outputElement, `Analyzing: ${foundTech.title}`);
            this.addTerminalMessage(outputElement, `Status: ${foundTech.badge}`);
            this.addTerminalMessage(outputElement, `Description: ${foundTech.description}`);
            
            // Simulate data processing
            setTimeout(() => {
                this.addTerminalMessage(outputElement, "Analysis complete.");
                this.addTerminalMessage(outputElement, `Adoption probability: ${Math.floor(Math.random() * 30) + 70}%`);
            }, 1000);
        } else {
            this.addTerminalMessage(outputElement, `Technology '${techName}' not found in database.`);
        }
    }

    simulateTechAnalysis(techName) {
        const terminalOutput = document.getElementById('terminal-output');
        if (!terminalOutput) return;

        this.addTerminalMessage(terminalOutput, `Initiating deep analysis of: ${techName}`);
        this.addTerminalMessage(terminalOutput, "Accessing prediction algorithms...");
        
        setTimeout(() => {
            this.addTerminalMessage(terminalOutput, "Calculating market impact...");
        }, 800);
        
        setTimeout(() => {
            this.addTerminalMessage(terminalOutput, "Projecting adoption curve...");
        }, 1600);
        
        setTimeout(() => {
            this.addTerminalMessage(terminalOutput, "Analysis complete.");
            this.addTerminalMessage(terminalOutput, "Prediction: HIGH IMPACT technology");
            this.addTerminalMessage(terminalOutput, "Recommended: Start learning now");
        }, 2400);
    }

    setupAnimations() {
        // Animate stat bars
        const statBars = document.querySelectorAll('.stat-fill');
        statBars.forEach(bar => {
            const targetWidth = bar.style.width;
            bar.style.width = '0%';
            
            setTimeout(() => {
                bar.style.width = targetWidth;
            }, 500);
        });

        // Add random data stream effects
        setInterval(() => {
            const randomStat = document.querySelectorAll('.stat-value')[Math.floor(Math.random() * 3)];
            if (randomStat && Math.random() > 0.7) {
                const originalValue = randomStat.textContent;
                const originalNum = parseInt(originalValue);
                
                // Briefly show updated value
                randomStat.textContent = `${originalNum + Math.floor(Math.random() * 3) - 1}%`;
                randomStat.style.color = '#ff003c';
                
                setTimeout(() => {
                    randomStat.textContent = originalValue;
                    randomStat.style.color = '#00ff41';
                }, 300);
            }
        }, 3000);
    }

    setupEventListeners() {
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Ctrl + 1-6 to navigate sections
            if (e.ctrlKey && e.key >= '1' && e.key <= '6') {
                e.preventDefault();
                const sections = ['core', 'styling', 'frameworks', 'ai', 'emerging', 'comparison'];
                const index = parseInt(e.key) - 1;
                
                if (sections[index]) {
                    // Update nav button
                    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
                    document.querySelector(`[data-section="${sections[index]}"]`).classList.add('active');
                    
                    // Show section
                    this.showSection(sections[index]);
                }
            }
            
            // Spacebar to randomize stats
            if (e.code === 'Space' && e.target.tagName !== 'INPUT') {
                e.preventDefault();
                this.randomizeStats();
            }
        });

        // Easter egg: Konami code
        let konamiCode = [];
        const konamiSequence = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'];
        
        document.addEventListener('keydown', (e) => {
            konamiCode.push(e.key);
            if (konamiCode.length > konamiSequence.length) {
                konamiCode.shift();
            }
            
            if (konamiCode.join(',') === konamiSequence.join(',')) {
                this.activateEasterEgg();
                konamiCode = [];
            }
        });
    }

    randomizeStats() {
        const stats = document.querySelectorAll('.stat-value');
        stats.forEach(stat => {
            const currentValue = parseInt(stat.textContent);
            const change = Math.floor(Math.random() * 10) - 5;
            const newValue = Math.max(0, Math.min(100, currentValue + change));
            
            stat.textContent = `${newValue}%`;
            
            // Update bar width
            const bar = stat.previousElementSibling?.querySelector('.stat-fill');
            if (bar) {
                bar.style.width = `${newValue}%`;
            }
            
            // Visual feedback
            HackerEffects.createPulseEffect(stat.parentElement);
        });
    }

    activateEasterEgg() {
        const title = document.querySelector('.title');
        const originalText = title.textContent;
        
        // Matrix-style text scramble
        const chars = '01';
        let iterations = 0;
        const maxIterations = 30;
        
        const scrambleInterval = setInterval(() => {
            title.textContent = originalText.split('').map(() => 
                chars.charAt(Math.floor(Math.random() * chars.length))
            ).join('');
            
            iterations++;
            
            if (iterations >= maxIterations) {
                clearInterval(scrambleInterval);
                title.textContent = originalText;
                title.style.color = '#00ff41';
                
                // Add secret message to terminal
                const terminalOutput = document.getElementById('terminal-output');
                if (terminalOutput) {
                    this.addTerminalMessage(terminalOutput, "SECRET UNLOCKED: The real future is quantum...");
                    this.addTerminalMessage(terminalOutput, "Quantum frontend frameworks arriving 2027");
                    this.addTerminalMessage(terminalOutput, "Stay tuned. The future is coming faster than predicted.");
                }
            }
        }, 50);
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const app = new Frontend2026App();
    
    // Make app globally available for console debugging
    window.app = app;
    
    console.log('%c🔮 Frontend 2026 Predictions Loaded', 'color: #00ff41; font-size: 18px; font-weight: bold;');
    console.log('%cTry pressing Space to randomize stats or enter Konami code for secrets!', 'color: #ff003c;');
});