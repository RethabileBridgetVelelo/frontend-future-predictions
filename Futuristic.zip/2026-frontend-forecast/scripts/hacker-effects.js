// Hacker-themed visual effects
class HackerEffects {
    constructor() {
        this.initMatrixBackground();
        this.initGlitchEffects();
        this.initTerminalTyping();
        this.initTimeDisplay();
    }

    initMatrixBackground() {
        // Create falling code effect
        const matrixContainer = document.querySelector('.matrix-background');
        if (!matrixContainer) return;

        // Add digital rain effect
        const canvas = document.createElement('canvas');
        canvas.style.position = 'fixed';
        canvas.style.top = '0';
        canvas.style.left = '0';
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        canvas.style.zIndex = '-1';
        canvas.style.opacity = '0.03';
        document.body.appendChild(canvas);

        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const chars = '01';
        const fontSize = 14;
        const columns = canvas.width / fontSize;
        const drops = [];

        // Initialize drops
        for (let i = 0; i < columns; i++) {
            drops[i] = Math.floor(Math.random() * canvas.height / fontSize) * fontSize;
        }

        function drawMatrix() {
            // Semi-transparent black background for trail effect
            ctx.fillStyle = 'rgba(5, 5, 5, 0.04)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            ctx.fillStyle = '#00ff41'; // Matrix green
            ctx.font = `${fontSize}px 'JetBrains Mono'`;

            for (let i = 0; i < drops.length; i++) {
                const text = chars.charAt(Math.floor(Math.random() * chars.length));
                const x = i * fontSize;
                const y = drops[i] * fontSize;

                ctx.fillText(text, x, y);

                // Reset drop to top when it reaches bottom
                if (y > canvas.height && Math.random() > 0.975) {
                    drops[i] = 0;
                }

                // Move drop down
                drops[i]++;
            }
        }

        // Animation
        let matrixInterval = setInterval(drawMatrix, 50);

        // Handle resize
        window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            clearInterval(matrixInterval);
            
            // Recalculate columns
            const newColumns = canvas.width / fontSize;
            drops.length = newColumns;
            for (let i = 0; i < newColumns; i++) {
                if (!drops[i]) {
                    drops[i] = Math.floor(Math.random() * canvas.height / fontSize) * fontSize;
                }
            }
            
            matrixInterval = setInterval(drawMatrix, 50);
        });
    }

    initGlitchEffects() {
        // Add random glitch to elements with .glitch class
        const glitchElements = document.querySelectorAll('.glitch');
        
        glitchElements.forEach(element => {
            setInterval(() => {
                if (Math.random() > 0.7) {
                    element.style.textShadow = `
                        ${Math.random() * 3}px ${Math.random() * 3}px 0 #ff003c,
                        ${Math.random() * -3}px ${Math.random() * -3}px 0 #00ff41
                    `;
                    
                    setTimeout(() => {
                        element.style.textShadow = 'var(--text-glow)';
                    }, 50);
                }
            }, 2000);
        });

        // Add random border glitches
        setInterval(() => {
            if (Math.random() > 0.8) {
                const cards = document.querySelectorAll('.card');
                const randomCard = cards[Math.floor(Math.random() * cards.length)];
                
                if (randomCard) {
                    randomCard.style.borderColor = '#00ff41';
                    randomCard.style.boxShadow = '0 0 20px #00ff41';
                    
                    setTimeout(() => {
                        randomCard.style.borderColor = '';
                        randomCard.style.boxShadow = '';
                    }, 300);
                }
            }
        }, 3000);
    }

    initTerminalTyping() {
        const terminalOutput = document.getElementById('terminal-output');
        if (!terminalOutput) return;

        let messageIndex = 0;
        let charIndex = 0;
        let isDeleting = false;
        let currentMessage = '';

        function typeTerminalMessage() {
            if (!terminalOutput) return;

            const messages = [
                ">> Initializing 2026 prediction matrix...",
                ">> Analyzing current trends...",
                ">> Processing AI development data...",
                ">> Calculating adoption curves...",
                ">> Predicting technology shifts...",
                ">> WASM adoption: 65% increase projected",
                ">> TypeScript: Becoming mandatory",
                ">> WebGPU: Game changer for browser AI",
                ">> Edge computing: Default by 2026",
                ">> AI-assisted dev: 40% productivity boost",
                ">> Zero-JS frameworks gaining traction",
                ">> CSS-in-JS moving to compile-time",
                ">> Prediction complete. Confidence: 87%"
            ];

            if (messageIndex >= messages.length) {
                messageIndex = 0;
            }

            currentMessage = messages[messageIndex];

            if (!isDeleting && charIndex <= currentMessage.length) {
                terminalOutput.innerHTML = `<div class="terminal-line"><span class="prompt">${currentMessage.substring(0, charIndex)}</span></div>`;
                charIndex++;
                setTimeout(typeTerminalMessage, 30);
            } else if (isDeleting && charIndex >= 0) {
                terminalOutput.innerHTML = `<div class="terminal-line"><span class="prompt">${currentMessage.substring(0, charIndex)}</span></div>`;
                charIndex--;
                setTimeout(typeTerminalMessage, 20);
            } else {
                isDeleting = !isDeleting;
                if (!isDeleting) {
                    messageIndex++;
                }
                setTimeout(typeTerminalMessage, 1000);
            }

            // Scroll to bottom
            terminalOutput.scrollTop = terminalOutput.scrollHeight;
        }

        // Start typing after a delay
        setTimeout(typeTerminalMessage, 1000);
    }

    initTimeDisplay() {
        const timeElement = document.getElementById('current-time');
        if (!timeElement) return;

        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('en-US', {
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
            
            timeElement.textContent = timeString;
            
            // Add glitch effect randomly
            if (Math.random() > 0.9) {
                timeElement.style.color = '#ff003c';
                setTimeout(() => {
                    timeElement.style.color = '#00ff41';
                }, 100);
            }
        }

        updateTime();
        setInterval(updateTime, 1000);
    }

    static createPulseEffect(element) {
        if (!element) return;

        element.style.animation = 'pulse 2s infinite';
        
        setTimeout(() => {
            element.style.animation = '';
        }, 2000);
    }

    static simulateDataStream(element, data) {
        if (!element || !data) return;

        let index = 0;
        const interval = setInterval(() => {
            if (index < data.length) {
                element.textContent += data.charAt(index);
                index++;
                
                // Scroll to bottom if element has scroll
                if (element.scrollHeight > element.clientHeight) {
                    element.scrollTop = element.scrollHeight;
                }
            } else {
                clearInterval(interval);
            }
        }, 50);
    }
}

// Initialize effects when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new HackerEffects();
});